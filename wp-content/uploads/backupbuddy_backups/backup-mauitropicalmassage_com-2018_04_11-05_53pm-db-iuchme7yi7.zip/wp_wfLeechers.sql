CREATE TABLE `wp_wfLeechers` (  `eMin` int(10) unsigned NOT NULL,  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `hits` int(10) unsigned NOT NULL,  PRIMARY KEY (`eMin`,`IP`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfLeechers` DISABLE KEYS */;
INSERT INTO `wp_wfLeechers` VALUES('25390888', '\0\0\0\0\0\0\0\0\0\0�����', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388797', '\0\0\0\0\0\0\0\0\0\0���E�B', '2');
INSERT INTO `wp_wfLeechers` VALUES('25389932', '\0\0\0\0\0\0\0\0\0\0���E�H', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389347', '\0\0\0\0\0\0\0\0\0\0���E�;', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391753', '\0\0\0\0\0\0\0\0\0\0��`/��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390089', '\0\0\0\0\0\0\0\0\0\0���w�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390191', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390246', '\0\0\0\0\0\0\0\0\0\0��-7�', '9');
INSERT INTO `wp_wfLeechers` VALUES('25390288', '\0\0\0\0\0\0\0\0\0\0��1�L', '3');
INSERT INTO `wp_wfLeechers` VALUES('25389660', '\0\0\0\0\0\0\0\0\0\0��B�D', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389086', '\0\0\0\0\0\0\0\0\0\0���L�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390343', '\0\0\0\0\0\0\0\0\0\0��E��w', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390344', '\0\0\0\0\0\0\0\0\0\0��E��w', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390423', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388736', '\0\0\0\0\0\0\0\0\0\0��B[b�', '3');
INSERT INTO `wp_wfLeechers` VALUES('25388734', '\0\0\0\0\0\0\0\0\0\0��B[b�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388716', '\0\0\0\0\0\0\0\0\0\0��.ج\Z', '2');
INSERT INTO `wp_wfLeechers` VALUES('25388681', '\0\0\0\0\0\0\0\0\0\0��]��\\', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388643', '\0\0\0\0\0\0\0\0\0\0���E��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388587', '\0\0\0\0\0\0\0\0\0\0����3', '3');
INSERT INTO `wp_wfLeechers` VALUES('25388475', '\0\0\0\0\0\0\0\0\0\0���UQ{', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388396', '\0\0\0\0\0\0\0\0\0\0���2r', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389547', '\0\0\0\0\0\0\0\0\0\0���E�<', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388370', '\0\0\0\0\0\0\0\0\0\0��]��\\', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391228', '\0\0\0\0\0\0\0\0\0\0���7\'�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25391228', '\0\0\0\0\0\0\0\0\0\0���7\'', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391207', '\0\0\0\0\0\0\0\0\0\0��M\"', '2');
INSERT INTO `wp_wfLeechers` VALUES('25391170', '\0\0\0\0\0\0\0\0\0\0��b��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390912', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388797', '\0\0\0\0\0\0\0\0\0\0���E�?', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388954', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388250', '\0\0\0\0\0\0\0\0\0\0����=', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389410', '\0\0\0\0\0\0\0\0\0\0���6�}', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389083', '\0\0\0\0\0\0\0\0\0\0���L�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389027', '\0\0\0\0\0\0\0\0\0\0��B�&', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390888', '\0\0\0\0\0\0\0\0\0\0��]��\\', '2');
INSERT INTO `wp_wfLeechers` VALUES('25388250', '\0\0\0\0\0\0\0\0\0\0��d+Us', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389083', '\0\0\0\0\0\0\0\0\0\0���L', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390471', '\0\0\0\0\0\0\0\0\0\0����X�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390472', '\0\0\0\0\0\0\0\0\0\0����X�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390751', '\0\0\0\0\0\0\0\0\0\0��P�Y', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390623', '\0\0\0\0\0\0\0\0\0\0���E��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25388250', '\0\0\0\0\0\0\0\0\0\0����', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390719', '\0\0\0\0\0\0\0\0\0\0���E�;', '1');
/*!40000 ALTER TABLE `wp_wfLeechers` ENABLE KEYS */;
