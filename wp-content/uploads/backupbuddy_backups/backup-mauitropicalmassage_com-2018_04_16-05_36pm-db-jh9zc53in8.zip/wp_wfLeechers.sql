CREATE TABLE `wp_wfLeechers` (  `eMin` int(10) unsigned NOT NULL,  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `hits` int(10) unsigned NOT NULL,  PRIMARY KEY (`eMin`,`IP`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfLeechers` DISABLE KEYS */;
INSERT INTO `wp_wfLeechers` VALUES('25397754', '\0\0\0\0\0\0\0\0\0\0����od', '1');
INSERT INTO `wp_wfLeechers` VALUES('25398483', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25397857', '\0\0\0\0\0\0\0\0\0\0��^��:', '1');
INSERT INTO `wp_wfLeechers` VALUES('25396866', '\0\0\0\0\0\0\0\0\0\0��\"��D', '1');
INSERT INTO `wp_wfLeechers` VALUES('25396737', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25396915', '\0\0\0\0\0\0\0\0\0\0�����', '1');
INSERT INTO `wp_wfLeechers` VALUES('25397019', '\0\0\0\0\0\0\0\0\0\0����', '1');
INSERT INTO `wp_wfLeechers` VALUES('25395890', '\0\0\0\0\0\0\0\0\0\0��]��\\', '1');
INSERT INTO `wp_wfLeechers` VALUES('25397232', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25395774', '\0\0\0\0\0\0\0\0\0\0���L', '1');
INSERT INTO `wp_wfLeechers` VALUES('25397325', '\0\0\0\0\0\0\0\0\0\0��6젻', '3');
INSERT INTO `wp_wfLeechers` VALUES('25398936', '\0\0\0\0\0\0\0\0\0\0��-7�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25398765', '\0\0\0\0\0\0\0\0\0\0��H��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25398514', '\0\0\0\0\0\0\0\0\0\0����', '2');
INSERT INTO `wp_wfLeechers` VALUES('25397670', '\0\0\0\0\0\0\0\0\0\0��j\Z�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25396915', '\0\0\0\0\0\0\0\0\0\0��]��\\', '2');
/*!40000 ALTER TABLE `wp_wfLeechers` ENABLE KEYS */;
