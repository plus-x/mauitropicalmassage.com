CREATE TABLE `wp_wfLeechers` (  `eMin` int(10) unsigned NOT NULL,  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',  `hits` int(10) unsigned NOT NULL,  PRIMARY KEY (`eMin`,`IP`)) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40000 ALTER TABLE `wp_wfLeechers` DISABLE KEYS */;
INSERT INTO `wp_wfLeechers` VALUES('25390888', '\0\0\0\0\0\0\0\0\0\0�����', '1');
INSERT INTO `wp_wfLeechers` VALUES('25392473', '\0\0\0\0\0\0\0\0\0\0����0', '1');
INSERT INTO `wp_wfLeechers` VALUES('25389932', '\0\0\0\0\0\0\0\0\0\0���E�H', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391843', '\0\0\0\0\0\0\0\0\0\0��\"���', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391753', '\0\0\0\0\0\0\0\0\0\0��`/��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390089', '\0\0\0\0\0\0\0\0\0\0���w�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390191', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390246', '\0\0\0\0\0\0\0\0\0\0��-7�', '9');
INSERT INTO `wp_wfLeechers` VALUES('25390288', '\0\0\0\0\0\0\0\0\0\0��1�L', '3');
INSERT INTO `wp_wfLeechers` VALUES('25389660', '\0\0\0\0\0\0\0\0\0\0��B�D', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390343', '\0\0\0\0\0\0\0\0\0\0��E��w', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390344', '\0\0\0\0\0\0\0\0\0\0��E��w', '2');
INSERT INTO `wp_wfLeechers` VALUES('25390423', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391857', '\0\0\0\0\0\0\0\0\0\0��[k`o', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391228', '\0\0\0\0\0\0\0\0\0\0���7\'�', '2');
INSERT INTO `wp_wfLeechers` VALUES('25391228', '\0\0\0\0\0\0\0\0\0\0���7\'', '1');
INSERT INTO `wp_wfLeechers` VALUES('25391207', '\0\0\0\0\0\0\0\0\0\0��M\"', '2');
INSERT INTO `wp_wfLeechers` VALUES('25391170', '\0\0\0\0\0\0\0\0\0\0��b��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390912', '\0\0\0\0\0\0\0\0\0\0���E�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25393143', '\0\0\0\0\0\0\0\0\0\0����6', '1');
INSERT INTO `wp_wfLeechers` VALUES('25392247', '\0\0\0\0\0\0\0\0\0\0��4��3', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390888', '\0\0\0\0\0\0\0\0\0\0��]��\\', '2');
INSERT INTO `wp_wfLeechers` VALUES('25392807', '\0\0\0\0\0\0\0\0\0\0���X|�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25392070', '\0\0\0\0\0\0\0\0\0\0��]��\\', '1');
INSERT INTO `wp_wfLeechers` VALUES('25392681', '\0\0\0\0\0\0\0\0\0\0��h�P�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390471', '\0\0\0\0\0\0\0\0\0\0����X�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390472', '\0\0\0\0\0\0\0\0\0\0����X�', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390751', '\0\0\0\0\0\0\0\0\0\0��P�Y', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390623', '\0\0\0\0\0\0\0\0\0\0���E��', '1');
INSERT INTO `wp_wfLeechers` VALUES('25392626', '\0\0\0\0\0\0\0\0\0\0����ox', '1');
INSERT INTO `wp_wfLeechers` VALUES('25390719', '\0\0\0\0\0\0\0\0\0\0���E�;', '1');
/*!40000 ALTER TABLE `wp_wfLeechers` ENABLE KEYS */;
