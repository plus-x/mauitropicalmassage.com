CREATE TABLE `wp_wfNet404s` (  `sig` binary(16) NOT NULL,  `ctime` int(10) unsigned NOT NULL,  `URI` varchar(1000) NOT NULL,  PRIMARY KEY (`sig`),  KEY `k1` (`ctime`)) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40000 ALTER TABLE `wp_wfNet404s` DISABLE KEYS */;
INSERT INTO `wp_wfNet404s` VALUES('����X�y�}v�\0��', '1523603916', '/contact-tus/');
/*!40000 ALTER TABLE `wp_wfNet404s` ENABLE KEYS */;
